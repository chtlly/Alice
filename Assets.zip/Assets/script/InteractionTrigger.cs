using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;

public class InteractionTrigger : MonoBehaviour
{
    [Header("��ȭ ���� (���� ��)")]
    public string[] dialogueText; // ���ڿ� �迭�� ����

    public GameObject talkPromptUI;
    private SpriteRenderer npcRanderer;

    // NPC �Ϸ���Ʈ ���
    public Sprite npcPortrait;

    private bool isPlayerInRange = false;

    private void Awake()
    {
        npcRanderer = GetComponent<SpriteRenderer>();
    }


    private void Start()
    {
        if (talkPromptUI != null)
        {
            talkPromptUI.SetActive(false);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = true;
            if (talkPromptUI != null)
            {
                talkPromptUI.SetActive(true);
            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = false;
            if (talkPromptUI != null)
            {
                talkPromptUI.SetActive(false);
            }

            if (TalkManager.instance != null)
            {
                TalkManager.instance.talkPanel.SetActive(false);
            }
            
        }
    }

    private void Update()
    {
        // �÷��̾ ���� �ȿ� �ְ�(isPlayerInRange) �����̽� �ٸ� ������
        if (isPlayerInRange && Input.GetKeyDown(KeyCode.Space))
        {
                // ��ȭâ�� �̹� Ȱ��ȭ�Ǿ� ������ ���� ��ȭ�� �ѱ��
                if (TalkManager.instance.talkPanel.activeSelf)
                {
                    TalkManager.instance.NextTalk();
                }
                else // ��ȭâ�� ��Ȱ��ȭ ���¶�� (ó�� ��ȭ ����) & npc Sprite �Ѱ��ֱ�
                {
                TalkManager.instance.StartTalk(dialogueText, npcPortrait);
                    if (talkPromptUI != null)
                    {
                        talkPromptUI.SetActive(false);
                    }
                }
            
        }
    }
}